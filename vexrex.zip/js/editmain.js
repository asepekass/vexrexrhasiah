ScatterJS.plugins( Vexanium() );
const fromDappBrowser = navigator.userAgent=='VexWalletAndroid';
const appname = document.title;
const network = ScatterJS.Network.fromJson({
	blockchain: bc('vex'),
	chainId:'f9f432b1851b5c179d2091a96f593aaed50ec7466b74f89301f957a83e56ce1f',
	host:'209.97.162.124',
	port:8080,
	protocol:'http'
});
let account;
let balance = '0.0000 VEX';

$('#login').on('click touch', function(){
	connect();
});

function connect() {
	try{
		if(!fromDappBrowser){
			ScatterJS.connect(appname,{network}).then(connected => {
				if(!connected) {
					notConnected();
					return;
				}
				login();
			});
		} else {
			pe.getWalletWithAccount().then((res)=>{
				if(!res) {
					notConnected();
					return;
				}
				account = res.data.account;
				onConnected();
			});	
		}
	} catch (e) {
		console.log(e);
	}
}
function notConnected(){
	$('#login).removeClass('d-none');
}
function onConnected(){
	$('#logout').removeClass('d-none');
	$('#logout').on('click touch', function(){
		logout();
	});
	getinfo(account);
}
function login() {
	try{
		ScatterJS.login().then(id => {
			if(!id) return;
			account = id.accounts[0].name;
			onConnected();
		});
	} catch (e) {
		console.log(e);
	}
}
function getinfo() {
	try {
		const vexnet = VexNet(network);
		vexnet.getAccount(account).then(info => {
			balance = info.core_liquid_balance?info.core_liquid_balance:balance;
		});
	} catch (e) {
		console.log(e);
	}
}
function logout() {
	try {
		if(!fromDappBrowser) ScatterJS.logout();
		sleepy();
	} catch (e) {
		console.log(e);
	}
}
